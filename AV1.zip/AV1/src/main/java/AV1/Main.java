package AV1;

import java.util.LinkedList;
import java.util.List;

public class Main {
    private List<Pessoa> listaPessoas = new LinkedList<>();

    public Pessoa criarPessoa(int id, String nome, String cpf, String telefone) {
        var pessoa = new Pessoa(id, nome, cpf, telefone);
        listaPessoas.add(pessoa);

        return pessoa;

    }

    private List<Conta> listaContas = new LinkedList<>();

    public Conta criarConta(int id, String dataAbertura, String senha, double saldo) {
        var conta = new Conta(id, dataAbertura, senha, saldo);
        listaContas.add(conta);

        return conta;
    }

}
